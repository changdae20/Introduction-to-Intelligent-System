# intelligence
지시개를 부수자 야야야2
