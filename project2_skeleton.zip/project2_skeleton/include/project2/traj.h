
struct traj{
	double x;
	double y;
	double th;
	double d;
	double alpha;
};
